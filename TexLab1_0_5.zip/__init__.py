"""
Title: Texture Lab
Description: Create PBR textures
Author: Luke Stilson
Date: 2024-11-13
Version: 1.0.2

Usage:
    python __init__.py
"""

import bpy
from bpy.types import Panel, Operator
import os

# needs to append uvlayout, texlab master, pbr default from relative resource file
TL_RESOURCES_BLEND_FILE = os.path.join(os.path.dirname(__file__), "texlab_resources.blend")

#TESTING ONLY
#TL_RESOURCES_BLEND_FILE = "/Users/luke/Library/CloudStorage/GoogleDrive-stilson.luke@gmail.com/My Drive/Extensions/TextureLab/texlab_workingFiles/Texlab_Working/texurelaboratory001/texlab_resources.blend"

def append_node_group(group_name):
    with bpy.data.libraries.load(TL_RESOURCES_BLEND_FILE, link=False) as (data_from, data_to):
        if group_name in data_from.node_groups:
            data_to.node_groups.append(group_name)
    
    # Ensure the node group is set to Fake User
    if group_name in bpy.data.node_groups:
        bpy.data.node_groups[group_name].use_fake_user = True

def ensure_node_group(group_name):
    if group_name not in bpy.data.node_groups:
        append_node_group(group_name)
        
def append_material(material_name):
    with bpy.data.libraries.load(TL_RESOURCES_BLEND_FILE, link=False) as (data_from, data_to):
        if material_name in data_from.materials:
            data_to.materials.append(material_name)

def ensure_material(material_name):
    if material_name not in bpy.data.materials:
        append_material(material_name)


class VIEW3D_PT_TexLab_Materials(bpy.types.Panel):
    """Creates a Panel in the Object properties window"""
    bl_label = "TexLab Materials"
    bl_idname = "VIEW3D_PT_texlab_materials"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'TexLab'

    @classmethod
    def poll(cls, context):
        # Only show the panel if the scene name ends with '_UVLayout'
        return context.scene.name.endswith('_UVLayout')

    def draw(self, context):
        layout = self.layout
        
        # Assuming you have a property that keeps track of the selected index for the filtered materials
        scene = context.scene
        mat_index = scene.texlab_mat_index
        
        # Draw the UI List
        layout.template_list("MATERIAL_UL_texlab_materials", "", bpy.data, "materials", scene, "texlab_mat_index")

        # Buttons for applying materials
        row = layout.row(align=True)
        row.operator("texlab.apply_to_active", text="Apply To Active")
        row.operator("texlab.apply_to_selected", text="Apply to Selected")
        row = layout.row()
        row.operator("texlab.new_material", text="New Texlab Material")

class ApplyToActive(bpy.types.Operator):
    """Apply the selected material to the active object"""
    bl_idname = "texlab.apply_to_active"
    bl_label = "Apply Material to Active Object"
    
    def execute(self, context):
        # Find material by name within the filtered list
        txl_materials = [mat for mat in bpy.data.materials]
        if context.scene.texlab_mat_index < len(txl_materials):
            mat = txl_materials[context.scene.texlab_mat_index]
            if mat and context.active_object:
                if context.active_object.data.materials:
                    context.active_object.data.materials[0] = mat
                else:
                    context.active_object.data.materials.append(mat)
            for area in bpy.context.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()

        return {'FINISHED'}

class ApplyToSelected(bpy.types.Operator):
    """Apply the selected material to all selected objects"""
    bl_idname = "texlab.apply_to_selected"
    bl_label = "Apply Material to Selected Objects"
    
    def execute(self, context):
        # Similar to ApplyToActive but for all selected objects
        txl_materials = [mat for mat in bpy.data.materials]
        if context.scene.texlab_mat_index < len(txl_materials):
            mat = txl_materials[context.scene.texlab_mat_index]
            if mat:
                for obj in context.selected_objects:
                    if obj.type == 'MESH':
                        if obj.data.materials:
                            obj.data.materials[0] = mat
                        else:
                            obj.data.materials.append(mat)
                    for area in bpy.context.screen.areas:
                        if area.type == 'VIEW_3D':
                            area.tag_redraw()
        return {'FINISHED'}

    
class MATERIAL_UL_texlab_materials(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        # This method is called for each item of the collection that the template_list is displaying
        if '.txl' in item.name:
            layout.label(text=item.name, translate=False, icon='MATERIAL')
            self.filter_name = ".txl"
              
class TEXLAB_OT_NewMaterial(bpy.types.Operator):
    bl_idname = "texlab.new_material"
    bl_label = "Create a new TexLab Material"
    
    def execute(self, context):
        ensure_node_group("texLab_master")
        ensure_node_group("TexLab_AutoTile")
        ensure_node_group("TexLab_AutoBlend")
        if "texLab_master" not in bpy.data.node_groups:
            self.report({'WARNING'}, "Node group 'texLab_master' not found.")
            return {'CANCELLED'}

        mat = bpy.data.materials.new(name="NewTXLMat.txl")
        mat.use_nodes = True
        nodes = mat.node_tree.nodes
        links = mat.node_tree.links
        
        # Clear default nodes
        nodes.clear()
        
        # Create a material output node
        output_node = nodes.new(type='ShaderNodeOutputMaterial')
        
        # Create node from 'texLab_master' node group
        group_node = nodes.new('ShaderNodeGroup')
        group_node.node_tree = bpy.data.node_groups['texLab_master']
        links.new(group_node.outputs[0], output_node.inputs[0])

        return {'FINISHED'}

def save_uv_layout(obj, file_path):
    ensure_material("PBR.Default")
    pbr_mat = bpy.data.materials.get("PBR.Default")
    if pbr_mat:
        if obj.material_slots:
            obj.material_slots[0].material = pbr_mat
        else:
            obj.data.materials.append(pbr_mat)

def setup_uv_scene(obj_name, uv_image_path):
    scene_name = f"{obj_name}_UVLayout"
    context = bpy.context
    settings = context.scene.texturelab_settings
    
    if scene_name not in bpy.data.scenes:
        new_scene = bpy.data.scenes.new(name=scene_name)
        # Camera setup
        cam_data = bpy.data.cameras.new(name='OrthoCam')
        cam_ob = bpy.data.objects.new(name='OrthoCam', object_data=cam_data)
        new_scene.collection.objects.link(cam_ob)
        new_scene.camera = cam_ob
        cam_data.type = 'ORTHO'
        cam_data.ortho_scale = 1
        cam_ob.location = (0.5, 0.5, 10)
        cam_data.passepartout_alpha = 1
    else:
        new_scene = bpy.data.scenes[scene_name]
        bpy.ops.object.select_all(action='DESELECT')
    bpy.context.window.scene = new_scene
    new_scene.render.resolution_x = 2048
    new_scene.render.resolution_y = 2048
    new_scene.render.image_settings.file_format = 'PNG'
    new_scene.render.image_settings.compression = 0
    new_scene.view_settings.view_transform = 'Raw'
    setup_3d_view(new_scene)
    setup_geometry_nodes(new_scene.name)
    bpy.context.space_data.shading.type = 'RENDERED'

class UVLayoutExportOperator(bpy.types.Operator):
    bl_idname = "object.uv_layout_export"
    bl_label = "Export UV Layout and Setup Scene"

    def execute(self, context):
        active_obj = bpy.context.active_object
        if active_obj:
            resources_dir = os.path.join(os.path.dirname(bpy.data.filepath), "Resources")
            uv_dir = os.path.join(resources_dir, "UVLayouts")
            uv_file_path = os.path.join(uv_dir, f"{active_obj.name}_UVLayout.png")
            #save_uv_layout(active_obj, uv_file_path)
            setup_uv_scene(active_obj.name, uv_file_path)
        return {'FINISHED'}

import bpy

def move_uncollected_objects_to_misc():
    # Get the current scene and its name
    scene = bpy.context.scene
    scene_name = scene.name
    
    # Define the name for the misc collection
    misc_collection_name = f"{scene_name}_misc"
    
    # Check if the misc collection already exists; if not, create it
    if misc_collection_name in bpy.data.collections:
        misc_collection = bpy.data.collections[misc_collection_name]
    else:
        misc_collection = bpy.data.collections.new(misc_collection_name)
        scene.collection.children.link(misc_collection)
    
    # Collect all objects not in any collection
    uncollected_objects = [
        obj for obj in scene.objects
        if not any(col for col in bpy.data.collections if obj.name in col.objects)
    ]
    
    # Move each uncollected object to the misc collection
    for obj in uncollected_objects:
        misc_collection.objects.link(obj)
        # Unlink from the scene collection if necessary
        if obj.name in scene.collection.objects:
            scene.collection.objects.unlink(obj)

    print(f"Moved {len(uncollected_objects)} uncollected objects to '{misc_collection_name}'.")

def setup_compositing_nodes():
    # Ensure compositing nodes are enabled
    scene = bpy.context.scene
    scene.use_nodes = True
    node_tree = scene.node_tree

    # Clear all nodes to start fresh
    for node in node_tree.nodes:
        node_tree.nodes.remove(node)

    # Create nodes
    render_layer_1 = node_tree.nodes.new(type="CompositorNodeRLayers")
    render_layer_1.name = "RenderLayer_Main"
    render_layer_1.layer = "ViewLayer"  # Main view layer
    
    render_layer_2 = node_tree.nodes.new(type="CompositorNodeRLayers")
    render_layer_2.name = "RenderLayer_Mask"
    render_layer_2.layer = f"{scene.name}Mask"  # Mask view layer

    color_ramp = node_tree.nodes.new(type="CompositorNodeValToRGB")
    color_ramp.label = "ColorRamp"
    color_ramp.color_ramp.interpolation = 'CONSTANT'

    set_alpha = node_tree.nodes.new(type="CompositorNodeSetAlpha")
    set_alpha.label = "SetAlpha"

    inpaint_node = node_tree.nodes.new(type="CompositorNodeInpaint")
    inpaint_node.label = "Inpaint"
    inpaint_node.distance = bpy.context.scene.tl_prop_group.render_resolution

    composite_output = node_tree.nodes.new(type="CompositorNodeComposite")
    composite_output.label = "CompositeOutput"

    # Position nodes for readability
    render_layer_1.location = (0, 300)
    render_layer_2.location = (0, 100)
    color_ramp.location = (200, 100)
    set_alpha.location = (400, 200)
    inpaint_node.location = (600, 200)
    composite_output.location = (800, 200)

    # Create connections between nodes
    node_tree.links.new(render_layer_2.outputs["Alpha"], color_ramp.inputs["Fac"])  # Mask alpha to Color Ramp input
    node_tree.links.new(color_ramp.outputs["Image"], set_alpha.inputs["Alpha"])     # Color Ramp output to Set Alpha node's Alpha input
    node_tree.links.new(render_layer_1.outputs["Image"], set_alpha.inputs["Image"]) # Main view layer Image to Set Alpha's Image input
    node_tree.links.new(set_alpha.outputs["Image"], inpaint_node.inputs["Image"])   # Set Alpha output to Inpaint node's Image input
    node_tree.links.new(inpaint_node.outputs["Image"], composite_output.inputs["Image"]) # Inpaint output to Composite node's Image input

def setup_mask_view_layer():
    # Get the current scene and its name
    scene = bpy.context.scene
    scene_name = scene.name
    
    # Define the collection and view layer names based on the scene name
    mask_layer_name = f"{scene_name}MaskLayer"
    mask_view_layer_name = f"{scene_name}Mask"
    
    # Check if the mask layer collection exists
    if mask_layer_name not in bpy.data.collections:
        print(f"Collection '{mask_layer_name}' not found.")
        return

    mask_collection = bpy.data.collections[mask_layer_name]

    # Access the current view layer
    current_view_layer = bpy.context.view_layer

    # Exclude the mask collection from the current view layer if it exists there
    for layer_collection in current_view_layer.layer_collection.children:
        if layer_collection.name == mask_collection.name:
            layer_collection.exclude = True

    # Check if the mask view layer already exists, otherwise create a new one
    if mask_view_layer_name not in scene.view_layers:
        mask_view_layer = scene.view_layers.new(name=mask_view_layer_name)
    else:
        mask_view_layer = scene.view_layers[mask_view_layer_name]

    # Set all collections to excluded in the new view layer
    for layer_collection in mask_view_layer.layer_collection.children:
        layer_collection.exclude = True

    # Include only the MaskLayer collection in the new view layer
    for layer_collection in mask_view_layer.layer_collection.children:
        if layer_collection.name == mask_collection.name:
            layer_collection.exclude = False

    # Set the new view layer as active
    bpy.context.window.view_layer = current_view_layer
    
def find_scene_for_object(object_name):
    for scene in bpy.data.scenes:
        if object_name in scene.objects:
            return scene.name
    return None

def render_and_update_normal(scene_name):
    object_name = scene_name.replace('_UVLayout', '')
    scene_name = find_scene_for_object(object_name)
    
    original_scene = bpy.data.scenes[scene_name]
    
    uv_layout_scene = bpy.data.scenes[scene_name]
    bpy.context.window.scene = uv_layout_scene
    obj = original_scene.objects.get(scene_name.replace('_UVLayout', ''))
    output_path = os.path.join(os.path.dirname(bpy.data.filepath), "Resources", "Textures", scene_name.replace('_UVLayout', '') + "_nrml.png")
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    uv_layout_scene.render.filepath = output_path
    bpy.ops.render.render(write_still=True)
    bpy.context.window.scene = bpy.data.scenes[scene_name]
    
    if obj:
        mat = obj.material_slots[0].material
        if mat and '_Normal' in mat.node_tree.nodes:
            normal_node = mat.node_tree.nodes['_normal']
            normal_node.image = bpy.data.images.load(output_path)
            normal_node.image.reload()
            normal_node.image.colorspace_settings.name = 'Non-Color'
            

def render_and_update_images(scene_name):
    context = bpy.context
    scene_name = context.scene.name
    
    move_uncollected_objects_to_misc()
    setup_viewlayer_mask(scene_name)
    setup_mask_view_layer()
    setup_compositing_nodes()
    
    context.scene.render.resolution_x = context.scene.tl_prop_group.render_resolution
    context.scene.render.resolution_y = context.scene.tl_prop_group.render_resolution
    settings = context.scene.texturelab_settings
    frame_suffixes = [
        (0, "_basecolor", settings.use_basecolor),
        (1, "_metallic", settings.use_metallic),
        (2, "_roughness", settings.use_roughness),
        (3, "_emission", settings.use_emission),
        (4, "_normal", settings.use_normal),
        (5, "_occlusion", settings.use_occlusion)
    ]
    color_spaces = ["sRGB", "sRGB", "sRGB", "Raw", "Raw", "sRGB"]  # This does not apply?
    color_modes = ["RGBA", "BW", "BW", "RGB", "RGB", "BW"]  # Assign color modes per frame
    
    ###
    
    # Define the original scene and target scene names
    object_name = scene_name.replace('_UVLayout', '')
    obj_scene_name = find_scene_for_object(object_name)
    original_scene = bpy.data.scenes[obj_scene_name]
    uv_layout_scene = bpy.data.scenes[scene_name]
    obj_name = scene_name.replace('_UVLayout', '')
    obj = original_scene.objects.get(obj_name)
    new_scene_name = f"{obj_name}_matView"
    target_obj_name = f"{obj_name}_matView"  # Consistent name for the duplicated object
    target_mat_name = f"{obj_name}_mat"  # Consistent name for the duplicated material

    # Check if the target scene already exists
    if new_scene_name not in bpy.data.scenes:
        # Create the new scene
        new_scene = bpy.data.scenes.new(name=new_scene_name)
        print(f"Scene '{new_scene_name}' created.")
    else:
        # Reference the existing scene
        new_scene = bpy.data.scenes[new_scene_name]
        print(f"Scene '{new_scene_name}' already exists.")

    # Check if the object already exists in the new scene by the target name
    obj_copy = new_scene.objects.get(target_obj_name)
    if not obj_copy:
        # Get the original object by name
        obj = original_scene.objects.get(obj_name)
        if obj:
            # Duplicate the object
            obj_copy = obj.copy()
            obj_copy.data = obj_copy.data.copy()  # Ensure unique mesh data block

            # Link the duplicated object to the new scene's collection
            new_scene.collection.objects.link(obj_copy)
            
            # Rename the duplicated object to ensure consistency
            obj_copy.name = target_obj_name
            print(f"Object '{obj_name}' duplicated, renamed to '{target_obj_name}', and added to scene '{new_scene_name}'.")
        else:
            print(f"Object '{obj_name}' not found in the original scene.")
    else:
        print(f"Object '{target_obj_name}' already exists in scene '{new_scene_name}'.")

    # Check if the material has already been duplicated and renamed
    new_mat = bpy.data.materials.get(target_mat_name)
    if not new_mat:
        # Get the original material

        ensure_material("PBR.Default")
        mat_name = "PBR.Default"
        mat = bpy.data.materials.get(mat_name)
        
        if mat:
            # Duplicate and rename the material
            new_mat = mat.copy()
            new_mat.name = target_mat_name
            print(f"Material '{mat_name}' duplicated and renamed to '{new_mat.name}'.")
        else:
            print(f"Material '{mat_name}' not found.")
    else:
        print(f"Material '{target_mat_name}' already exists.")

    # Ensure obj_copy has exactly one material slot with the new material
    if obj_copy:
        obj_copy.data.materials.clear()  # Clear any existing materials
        obj_copy.data.materials.append(new_mat)  # Assign the material
        print(f"Material '{new_mat.name}' applied to '{obj_copy.name}' with exactly one material slot.")
    
    ###
    
    # Define and create the relative path to render the exports
    base_path = os.path.join(os.path.dirname(bpy.data.filepath), "Resources", obj_name, "Textures")
    os.makedirs(base_path, exist_ok=True)
    
    current_frame = 0
    bpy.context.scene.eevee.taa_render_samples = 1  # Sampling to 1 for sharp renders
    bpy.context.scene.render.use_compositing = True
    bpy.context.scene.render.use_sequencer = False
    bpy.context.scene.eevee.overscan_size = 5
    
    for frame, suffix, use_frame in frame_suffixes:
        bpy.context.window.scene = uv_layout_scene
        uv_layout_scene.frame_set(current_frame + 1)
        
        # Set color space for specific frames
        if frame == 4:  # Normal maps
            uv_layout_scene.view_settings.view_transform = 'Raw'
            bpy.context.scene.render.film_transparent = True
        elif frame == 0:  # Base color frame
            bpy.context.scene.render.film_transparent = True
        else:
            uv_layout_scene.view_settings.view_transform = 'Standard'
            bpy.context.scene.render.film_transparent = True

        bpy.context.scene.render.image_settings.color_mode = color_modes[current_frame]
        output_path = os.path.join(base_path, obj_name + suffix + ".png")
        uv_layout_scene.render.filepath = output_path
        
        if use_frame:
            bpy.ops.render.render(write_still=True)

        current_frame += 1


    # Switch back to original scene for updating materials
    bpy.context.window.scene = bpy.data.scenes[new_scene_name]
    if obj_copy and obj_copy.material_slots:
        for mat_slot in obj_copy.material_slots:
            mat = mat_slot.material
            if mat and mat.node_tree:
                for frame, suffix, use_frame in frame_suffixes:
                    if use_frame:
                        node_name = suffix
                        image_path = os.path.join(base_path, obj_name + suffix + ".png")
                        image_name = obj_name + suffix + ".png"
                        if node_name in mat.node_tree.nodes:
                            img_node = mat.node_tree.nodes[node_name]
                            if image_name not in bpy.data.images:
                                img_node.image = bpy.data.images.load(image_path)
                            else:
                                img_node.image = bpy.data.images[image_name]
                                img_node.image.reload()
                            if frame in [4]:  # normal adjust color space
                                img_node.image.colorspace_settings.name = 'Non-Color'
                            else:
                                img_node.image.colorspace_settings.name = 'sRGB'

class RenderAndUpdateNormalOperator(bpy.types.Operator):
    bl_idname = "object.render_update_normal"
    bl_label = "Render UV Layout and Update Normal Map"

    def execute(self, context):
        scene_name = context.scene.name
        render_and_update_normal(scene_name)
        return {'FINISHED'}

class RenderAndUpdateImagesOperator(bpy.types.Operator):
    bl_idname = "object.render_update_images"
    bl_label = "Render UV Layout and Update Normal Map"

    def execute(self, context):
        scene_name = context.scene.name
        render_and_update_images(scene_name)
        return {'FINISHED'}
    
def setup_3d_view(scene_name):
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            space_data = area.spaces.active
            region_data = space_data.region_3d
            region_data.view_perspective = 'CAMERA'
            region_data.view_location = bpy.data.objects['OrthoCam'].location
            region_data.view_distance = 10
            space_data.overlay.show_floor = False
            break  

def setup_viewlayer_mask(scene_name):
    object_name = scene_name.replace('_UVLayout', '')
    reference_object_name = object_name + "_Mask"
    uv_reference_collection_name = scene_name + "MaskLayer"
    specific_scene = bpy.data.scenes.get(scene_name)
    
    # Verify scene existence
    if not specific_scene:
        print(f"Scene {scene_name} not found.")
        return

    # Ensure the MaskLayer collection exists
    uv_reference_collection = specific_scene.collection.children.get(uv_reference_collection_name)
    if not uv_reference_collection:
        uv_reference_collection = bpy.data.collections.new(uv_reference_collection_name)
        specific_scene.collection.children.link(uv_reference_collection)

    # Check or create the view layer named scene_name + "Mask"
    mask_viewlayer_name = scene_name + "Mask"
    mask_viewlayer = specific_scene.view_layers.get(mask_viewlayer_name)
    if not mask_viewlayer:
        mask_viewlayer = specific_scene.view_layers.new(name=mask_viewlayer_name)

    # Check if the reference object already exists in the collection
    reference_object = bpy.data.objects.get(reference_object_name)
    if reference_object:
        if reference_object.name in uv_reference_collection.objects:
            print(f"{reference_object_name} already exists in '{uv_reference_collection_name}' collection in '{scene_name}'. Skipping geometry nodes setup.")
            return
    else:
        # Create a new reference plane with the specified name and add it to the collection
        mesh = bpy.data.meshes.new(name=reference_object_name)
        plane = bpy.data.objects.new(reference_object_name, mesh)
        uv_reference_collection.objects.link(plane)
        
        # Find the object to reference for the Geometry Nodes modifier
        obj_to_reference = bpy.data.objects.get(object_name)
        if obj_to_reference:
            # Add a Geometry Nodes modifier to the reference plane
            mod = plane.modifiers.new(name="GeometryNodes", type='NODES')
            ensure_node_group("DisplayUVMap")
            node_group = bpy.data.node_groups.get("DisplayUVMap")
            if node_group:
                mod.node_group = node_group
            else:
                print("Node group 'DisplayUVMap' not found.")
                return
            
            # Set specific inputs on the Geometry Nodes modifier
            if "Socket_2_attribute_name" in mod:  # Check if this is the correct input name in your node group
                mod["Socket_2_attribute_name"] = "UVMap"  # Assign the UV map name
            
            if "Socket_3" in mod:
                mod["Socket_3"] = bpy.data.objects[object_name]
            bpy.context.view_layer.objects.active = plane
            
            # Apply the Geometry Nodes modifier
            bpy.ops.object.modifier_apply(modifier="GeometryNodes")
            
            # Assign a material to the plane if 'normalMat' exists
            normal_mat = bpy.data.materials.get("normalMat")
            if normal_mat:
                if plane.material_slots:
                    plane.material_slots[0].material = normal_mat
                else:
                    plane.data.materials.append(normal_mat)
            else:
                print("Material 'NormalMat' not found.")
    print(f"Setup for '{mask_viewlayer_name}' view layer and '{uv_reference_collection_name}' collection in '{scene_name}' completed.")

                
def setup_geometry_nodes(scene_name):
    object_name = scene_name.replace('_UVLayout', '')
    reference_object_name = object_name + "_UVReference"
    uv_reference_collection_name = scene_name + "UV"
    specific_scene = bpy.data.scenes.get(scene_name)
    if not specific_scene:
        print(f"Scene {scene_name} not found.")
        return
    uv_reference_collection = specific_scene.collection.children.get(uv_reference_collection_name)
    if not uv_reference_collection:
        uv_reference_collection = bpy.data.collections.new(uv_reference_collection_name)
        specific_scene.collection.children.link(uv_reference_collection)
    if reference_object_name in uv_reference_collection.objects:
        print(f"{reference_object_name} already exists in {uv_reference_collection_name} collection in {scene_name}. Skipping geometry nodes setup.")
        return
    else:
        mesh = bpy.data.meshes.new(name=reference_object_name)
        plane = bpy.data.objects.new(reference_object_name, mesh)
        uv_reference_collection.objects.link(plane)
        obj_to_reference = bpy.data.objects.get(object_name)
        if obj_to_reference:
            mod = plane.modifiers.new(name="GeometryNodes", type='NODES')
            ensure_node_group("DisplayUVMap")
            node_group = bpy.data.node_groups.get("DisplayUVMap")
            if node_group:
                mod.node_group = node_group
            else:
                print("Node group 'DisplayUVMap' not found.")
                return
            
            if "Socket_2_attribute_name" in mod:  # Check if this is the correct input name in your node group
                mod["Socket_2_attribute_name"] = "UVMap"  # Assign the UV map name
            
            if "Socket_3" in mod:
                mod["Socket_3"] = bpy.data.objects[object_name]
            bpy.context.view_layer.objects.active = plane
            
            normal_mat = bpy.data.materials.get("normalMat")
            if normal_mat:
                # Check if the plane already has some material slots
                if plane.material_slots:
                    # Replace the material in the first slot
                    plane.material_slots[0].material = normal_mat
                else:
                    # Create a new material slot and assign the material
                    plane.data.materials.append(normal_mat)
            else:
                print("Material 'NormalMat' not found.")
                    
            #bpy.ops.object.modifier_apply(modifier="GeometryNodes")

class UVLayoutPanel(bpy.types.Panel):
    bl_label = "Texture Laboratory"
    bl_idname = "OBJECT_PT_uv_layout_exporter"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'TexLab'

    def draw(self, context):
        layout = self.layout
        obj = context.object

        # Ensure the panel only shows if in a "_UVLayout" scene
        if context.scene.name.endswith('_UVLayout'):
            row = layout.row()
            prop_group = context.scene.tl_prop_group
            row.operator("object.render_update_images", text=f"Update Selected Textures for {context.scene.name.replace('_UVLayout', '')}")
            row = layout.row()
            row.prop(prop_group, "render_resolution")
            # Display current frame layer
            frame = context.scene.frame_current
            viewlayer = ["Lit Preview", "Basecolor", "Metallic", "Roughness", "Emission", "Normal", "Ambient Occlusion"]
            row = layout.row()
            row.label(text=f'Viewing : {viewlayer[frame]}')
            
            # Render options with toggles and buttons
            col = layout.column()
            frame_suffixes = [
                (1, "_basecolor", "Base Color"), 
                (2, "_metallic", "Metallic"), 
                (3, "_roughness", "Roughness"), 
                (4, "_emission", "Emission"), 
                (5, "_normal", "Normal"), 
                (6, "_occlusion", "Occlusion")
            ]

            # Confirm if texturelab_settings exist
            if hasattr(context.scene, "texturelab_settings"):
                for frame, suffix, label in frame_suffixes:
                    row = col.row()
                    row.prop(context.scene.texturelab_settings, f"use{suffix}", text=label)  # Modified prop call
                    op = row.operator("object.view_layer", text="View " + label)
                    op.layer = frame
            else:
                col.label(text="Properties not initialized", icon='ERROR')
        else:
            row = layout.row()
            row.operator("object.uv_layout_export", text="Export UV Layout and Setup Scene")

class OBJECT_OT_view_layer(bpy.types.Operator):
    bl_idname = "object.view_layer"
    bl_label = "View Layer Operator"
    
    # Define an integer property for this operator
    layer: bpy.props.IntProperty(
        name="layer",
        description="Select layer to view",
        min=0, max=5,
        default=0
    )

    def execute(self, context):
        bpy.context.scene.frame_current = self.layer
        
        return {'FINISHED'}
    
class TextureLabSettings(bpy.types.PropertyGroup):
    use_vyz: bpy.props.BoolProperty(name="View Y-Z", default=True)
    use_basecolor: bpy.props.BoolProperty(name="Base Color", default=True)
    use_metallic: bpy.props.BoolProperty(name="Metallic", default=True)
    use_roughness: bpy.props.BoolProperty(name="Roughness", default=True)
    use_emission: bpy.props.BoolProperty(name="Emission", default=True)
    use_normal: bpy.props.BoolProperty(name="Normal", default=True)
    use_occlusion: bpy.props.BoolProperty(name="Occlusion", default=True)

class TexLabPropGroup(bpy.types.PropertyGroup):
    render_resolution: bpy.props.IntProperty(
        name="Render Resolution",      # Name shown in the UI
        description="TextureLab Render Resolution",  # Tooltip
        default=2048,              # Default value
        min=16, max=8192          # Min and max values
    )
    
# Define the classes and properties to register
classes = [
    OBJECT_OT_view_layer,
    UVLayoutExportOperator,
    RenderAndUpdateNormalOperator,
    UVLayoutPanel,
    RenderAndUpdateImagesOperator,
    VIEW3D_PT_TexLab_Materials,
    MATERIAL_UL_texlab_materials,
    TEXLAB_OT_NewMaterial,
    ApplyToActive,
    ApplyToSelected,
    TextureLabSettings,
    TexLabPropGroup
]

# Define properties to add to bpy.types.Scene
def register_properties():
    bpy.types.Scene.tl_prop_group = bpy.props.PointerProperty(type=TexLabPropGroup)
    bpy.types.Scene.texturelab_settings = bpy.props.PointerProperty(type=TextureLabSettings)
    bpy.types.Scene.texlab_mat_index = bpy.props.IntProperty()
    bpy.types.Scene.view_pass_enum = bpy.props.EnumProperty(
        name="View Pass",
        items=[
            ('0', "Physical", "Set to Physical"),
            ('1', "Basecolor", "Set to Basecolor"),
            ('2', "Roughness", "Set to Roughness"),
            ('3', "Metallic", "Set to Metallic"),
            ('4', "Emission", "Set to Emission"),
            ('5', "Normal", "Set to Normal"),
            ('6', "Ambient Occlusion", "Set to Ambient Occlusion")
        ],
    )
    bpy.types.Scene.mat_index = bpy.props.IntProperty()
    bpy.types.Scene.mat_names = bpy.props.StringProperty()

# Remove properties from bpy.types.Scene
def unregister_properties():
    del bpy.types.Scene.tl_prop_group
    del bpy.types.Scene.texturelab_settings
    del bpy.types.Scene.texlab_mat_index
    del bpy.types.Scene.view_pass_enum
    del bpy.types.Scene.mat_index
    del bpy.types.Scene.mat_names

def register():
    # Register classes
    for cls in classes:
        bpy.utils.register_class(cls)
    
    # Register custom properties
    register_properties()

def unregister():
    # Unregister properties
    unregister_properties()
    
    # Unregister classes in reverse order
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

# Register if run as a script
if __name__ == "__main__":
    register()